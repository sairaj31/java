package crm.controller;

//@Controller
public class ExportCustomers {

//    @Autowired
//    CustomerService customerService;
//
//    /**
//     * Handle request to download an Excel document
//     */
//    @GetMapping("/download")
//    public String download(Model model) {
//        model.addAttribute("customers", customerService.listAllCustomers());
//        return "";
//    }

}
