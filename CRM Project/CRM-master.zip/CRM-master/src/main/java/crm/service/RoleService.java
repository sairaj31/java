package crm.service;

import crm.entity.Role;

public interface RoleService {

    Iterable<Role> listAllRoles();

}
