export interface CarStandart{
    carId?:number,
    colorId:number,
    brandId:number,
    carName:string,
    modelYear:number,
    dailyPrice:number,
    description:string,
    
}