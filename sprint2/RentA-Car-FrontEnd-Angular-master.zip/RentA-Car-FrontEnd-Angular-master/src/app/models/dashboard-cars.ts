export interface DashboardCars {
    carId: number;
    carName: string;
    brandName: string;
    colorName: string;
    dailyPrice: number;
    modelYear: number;
    description: string;
  }
  