  
export interface PasswordChangeModel{
    userId:number;
    oldPassword:string;
    newPassword:string;
}