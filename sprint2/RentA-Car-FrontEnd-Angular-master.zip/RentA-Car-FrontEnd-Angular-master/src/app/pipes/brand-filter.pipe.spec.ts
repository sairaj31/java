import { BrandFilterPipe } from './brand-filter.pipe';

describe('BrandFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new BrandFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
