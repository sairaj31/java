import { CarFilterPipe } from './car-filter.pipe';

describe('CarFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CarFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
