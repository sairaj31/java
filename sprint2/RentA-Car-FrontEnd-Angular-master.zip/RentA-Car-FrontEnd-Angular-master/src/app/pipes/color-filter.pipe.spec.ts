import { ColorFilterPipe } from './color-filter.pipe';

describe('ColorFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ColorFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
